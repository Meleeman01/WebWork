require('./d-common-specific.js')(require('../lib/D.min.js'));
